

  // Initialize Firebase
  var config = {
    apiKey: "AIzaSyCJj9IIKLq4KtNYtAOOQmq6waEp9QtQocU",
    authDomain: "smallboulo-worker.firebaseapp.com",
    databaseURL: "https://smallboulo-worker.firebaseio.com",
    projectId: "smallboulo-worker",
    storageBucket: "smallboulo-worker.appspot.com",
    messagingSenderId: "820545528906"
  };
  firebase.initializeApp(config);
