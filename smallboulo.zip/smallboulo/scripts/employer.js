// all of my Javascript/jquery code is in this function
$(function() {
	var email = document.getElementById("signupEmail");
	var password = document.getElementById("signupPassword");
	var confirmPassword = document.getElementById("confirmPassword");
	var yname = document.getElementById("signupName");
	var gender = document.getElementById("signupGender");
	var skill = document.getElementById("signupSkill");
	var birthDate = document.getElementById("signupDOB");
	var country = document.getElementById("signupCountry");
	var city = document.getElementById("signupCity");
	var number = document.getElementById("signupTel");

	//check is user is authenticated and the do stuffs
	isUserAuth();

	/*var userId = firebase.auth().currentUser.uid;
	return firebase.database().ref('/users/employers/' + userId).once('value').then(function(snapshot) {
	  var username = snapshot.val().username;
	  // ...
	  window.alert(username);
	});*/

	
	//what happends when a user clicks on next
	$("#nextClick").click(function(){
		if (email.value == "" && password.value == "") {
			$("#signupError").show().text("Please fill all the fields");
			return false;
		}

		if (password.value != confirmPassword.value) {
			$("#signupError").show().text("Passwords do not match");
			return false;
		}
		if (password.value.length <= 6){
			$("#signupError").show().text("Password should be at least 6 characters");
			return false;
		}

		if (email.value != "" && password.value != "") {
			createUserAccount();
		}
	})

	// what should happen when a user clicks on a the employer signup button
	$("#eSignupBtn").click(function () {

		if (yname.value!=""&&gender.value!=""&&birthDate.value!=""&&country.value!=""&&city.value!=""&&number.value!="") {
			empWriteUserData();
		} else {
			return false;
		}
	});


	//what should happen when a user clicks on the employer login button
	$("#eLoginBtn").click(function (){
		var eemail = $("#loginEmail").val();
		var ppassword = $("#loginPassword").val();
		$("#loader").show();
		$("#eLoginBtn").hide();
		if (eemail != "" && ppassword != "") {
			signUserIn();
			$("#loginError").hide();
			return false;
		} else {
			$("#loginError").show().text("Please fill all the fields");
			$("#eLoginBtn").show();
			$("#loader").hide();
			return false;
		}
	});


	/* what happens after a user selects a workflow, either employer workflow
		or worker workflow and decides to login to the selected workflow */
	$("#EWLoginBtn").click(function (){
		var selectedWF = $("#selectedWF").val();
		window.alert(selectedWF);
		var eemail = $("#loginEmail").val();
		var ppassword = $("#loginPassword").val();
		if (eemail != "" && ppassword != "") {
			signUserIn();
			$("#loginError").hide();
			return false;
		} else {
			$("#loginError").show().text("Please fill all the fields");
			return false;
		}
		window.location.replace("employerHomeSearch.html");
	});

	//what should happen when a user clicks on the logout button
	$("#logoutBtn").click(function (){
		if ($(".empLogOut")) {
			userLogOut("employerHomeSearch.html");
		}
		if ($(".wLogOut")) {
			userLogOut("workerHomeSearch.html");
		}
	});


	// function to write employers information to the database
	function empWriteUserData() {
		
		firebase.database().ref('users/employers/').push().set({
			username: yname.value,
			email: email.value,
			gender: gender.value,
			birthDate: birthDate.value,
			cellNumber: number.value,
			country: country.value,
			city: city.value
		});
	}


	// function to create a clients account
	function createUserAccount() {
		firebase.auth().createUserWithEmailAndPassword(email.value, password.value).catch(function(error) {
			// Handle Errors here.
			var errorCode = error.code;
			var errorMessage = error.message;
			if (errorMessage != "") {
				$("#signupError").show().text(errorMessage);
				return false;
			} else {
				$("#signupSuccess").show().text("You have successfully created an accout.");
				return false;
				//window.location.href ="employerHomeSearch.html";
			}
		});
		
	}

	//function to log a user into his/her account
	function signUserIn() {
		var email = $("#loginEmail").val();
		var password = $("#loginPassword").val();
		firebase.auth().signInWithEmailAndPassword(email, password).then(function(){
			window.location.href = "employerHomeSearch.html";
		}).catch(function(error) {
			// Handle Errors here.
			var errorCode = error.code;
			var errorMessage = error.message;
			$("#loginError").show().text(error.message);
			$("#loader").hide();
			$("#eLoginBtn").show();
		});
	}

	//function checks if user is logged in or not
	function isUserAuth() {
		firebase.auth().onAuthStateChanged(function(user) {
		  if (user) {
		    // User is signed in.
		    $("#loginSuccess").show().text("You have successfully logged in. Please close this box");
		    $("#loginLk").hide();
		    $("#signupLk").hide();
		    window.alert(user.birthDate);
		  } else {
		    // No user is signed in.
		    $("#logoutBtn").hide();
		    $("#employerProfile").hide();
		  }
		});
	}

	//function to log a user out
	function userLogOut() {
		firebase.auth().signOut().then(function() {
		  // Sign-out successful.
		  window.location.href = "employerHomeSearch.html";
		}).catch(function(error) {
		  // An error happened.
		  window.alert(error);
		});
	}

	//function to handle to next/prev events
	function showModal(id) {
      
    }
});
