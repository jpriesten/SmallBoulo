

 // Initialize Firebase
  var config = {
    apiKey: "AIzaSyA4PzZELQhyu7A3czLBjlk7HjTjTg3w8xY",
    authDomain: "smallboulo-employer.firebaseapp.com",
    databaseURL: "https://smallboulo-employer.firebaseio.com",
    projectId: "smallboulo-employer",
    storageBucket: "smallboulo-employer.appspot.com",
    messagingSenderId: "127672902278"
  };
  firebase.initializeApp(config);
