
var email = document.getElementById("signupEmail");
var password = document.getElementById("signupPassword");
var confirmPassword = document.getElementById("confirmPassword");
var yname = document.getElementById("signupName");
var gender = document.getElementById("signupGender");
var birthDate = document.getElementById("signupDOB");
var country = document.getElementById("signupCountry");
var city = document.getElementById("signupCity");
var number = document.getElementById("signupTel");


$("#signupBtn").click(function () {

	if (password.value != confirmPassword.value) {
		window.alert("Passwords do not match");
		return false;
	}

	if (email.value != "" && password.value != "") {
		createUserAccount();
	} else {
		return false;
	}
	if (yname.value!=""&&gender.value!=""&&birthDate.value!=""&&country.value!=""&&city.value!=""&&number.value!="") {
		writeUserData();
	} else {
		return false;
	}
	

});

// function to write clients information to database
function writeUserData() {
	
	firebase.database().ref('users/').push().set({
		username: yname.value,
		email: email.value,
		gender: gender.value,
		birthDate: birthDate.value,
		cellNumber: number.value,
		country: country.value,
		city: city.value
	});
}

// function to create a clients account
function createUserAccount() {
	firebase.auth().createUserWithEmailAndPassword(email.value, password.value).catch(function(error) {
	  // Handle Errors here.
	  var errorCode = error.code;
	  var errorMessage = error.message;
	  window.alert(errorCode);
	  window.alert(errorMessage);
	  // ...
	});
}
