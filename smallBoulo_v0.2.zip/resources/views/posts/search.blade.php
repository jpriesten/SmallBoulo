	
	<div>
	  <h4>{{ $searchR->userSkill }} Needing!</h4>
	  <p>With supporting text below as a natural lead-in to additional content.</p>
	  <a href="/searchResult/{{$searchR->bouloId}}"><small>Category of Job</small></a>
	  <hr>
	</div>