	
	<div>
	  <h4>{{ $post->userSkill }} Needed!</h4>
	  <p>With supporting text below as a natural lead-in to additional content.</p>
	  <small>Category of Job</small>
	  <hr>
	</div>