<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class WorkerEmployerDealsController extends Controller
{
    //
}
