<?php $__env->startSection('content'); ?>

    <link rel="stylesheet" type="text/css" href="/css/empPages.css">
    

    
    <div class="pageContent">
        <div class="container">
            <div class="row">
                

                  <!-- dashboard -->
                 <div class="col-md-10">
                 
                    <?php $__currentLoopData = $SearchR; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $searchR): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <?php echo $__env->make('posts.search', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                 </div> <!-- closing of dashboard -->

                 
            </div>
        </div>

    </div>

<?php $__env->stopSection(); ?>

	  	

<?php echo $__env->make('layouts.employer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>